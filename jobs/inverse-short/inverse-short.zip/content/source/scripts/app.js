//
// 
// APP.JS
//
//

$(document).ready(function () {

    //CONFIGS
    var appVersion = '1.0'; 
    var baseUrl = $('body').data('baseurl');
    window.siteUrl = $('body').data('siteurl');

    //CONTROLLER CALLS
    controllerCommon();
    
});